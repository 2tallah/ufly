<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class GiftRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        $rules = [
            'points' => 'required|numeric',
        ];
        foreach (locales() as $key => $language) {
            $rules['name_' . $key] = 'required|string|max:255';
            $rules['details_' . $key] = 'required|string|max:255';
        }

        if ($this->getMethod() == 'POST') {
            $rules += ['images' => 'required|image'];
        }
        if ($this->getMethod() == 'PUT') {
            $rules += ['images' => 'nullable|image'];
        }
        return $rules;

    }
}
