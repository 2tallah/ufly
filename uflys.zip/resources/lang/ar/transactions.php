<?php

return [
    'management' => 'إدارة العمليات المالية',
    'transactions' => 'العمليات المالية',
    'transaction' => 'العملية المالية',
    'discount' => 'قيمة الخصم',
    'payment_method' => 'طريقة الدفع',
    'deposit' => 'ايداع',
    'withdraw' => 'سحب',
    'wallet' => 'المحفظة',
    'mada' => 'مدى',
    'visa' => 'فيزا',
    'amount' => 'المبلغ',
    'total' => 'المبلغ الكلي',
];
